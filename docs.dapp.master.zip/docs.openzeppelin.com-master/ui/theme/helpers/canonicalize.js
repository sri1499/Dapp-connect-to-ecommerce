module.exports = (url) => url.replace(/(\/index)?\.html$/, '');
