import './js/03-page-version-selector.js';
import './js/04-page.js';
import './js/05-sidr-menu.js';
import './js/06-hardhat-truffle-toggle.js';
import './js/07-copy-code.js';
import './js/highlight.js';

import './css/index.scss';
